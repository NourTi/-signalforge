# SignalForge Application Source

This directory contains the **actual full-stack SignalForge product source**: the React interface, TypeScript/Express server, tRPC API contracts, Drizzle/MySQL schema, product services, and Vitest coverage. It is intentionally separate from the static GitHub Pages files at the repository root.

## Stack

| Layer | Technology |
| --- | --- |
| Client | React 19, TypeScript, Tailwind CSS 4, Wouter, TanStack Query |
| Server | Node.js, Express 4, tRPC 11, Zod |
| Database | MySQL-compatible database through Drizzle ORM |
| Product services | Google Places discovery, visible-site email extraction, SMTP delivery, optional Telegram alerts, LLM-assisted drafts |
| Quality | Vitest |

## Source map

| Path | Purpose |
| --- | --- |
| `client/src/pages/` | Dashboard, discovery, pipeline, outreach, settings, compliance, and product guidance screens |
| `server/routers.ts` | Typed API surface and approval-gated workflows |
| `server/discovery.ts` | Public-business discovery and official-site email scanning |
| `server/compliance.ts` | Suppression, opt-out, signing, daily-limit, readiness, and footer controls |
| `server/email.ts` | SMTP transport and dispatch implementation |
| `server/secretCrypto.ts` | AES-256-GCM encryption helpers for credentials at rest |
| `drizzle/schema.ts` | MySQL schema for leads, drafts, activity, sender settings, suppression, and policies |
| `server/*.test.ts` | Regression coverage for workflow and compliance guards |

## Local development

Use Node.js 22+ and pnpm 10+.

```bash
cd app
pnpm install
pnpm db:push
pnpm dev
```

Configure the variables described in [`ENVIRONMENT.md`](./ENVIRONMENT.md) through a private local environment file or your deployment platform's secret manager. **Never commit local environment files, SMTP passwords, database URLs, tokens, or real API keys.**

## External deployment note

This codebase was built on an application platform that supplies a few runtime adapters under `server/_core/` for authentication, storage, maps, LLM access, and owner notifications. The product modules, UI, API, schema, workflows, and tests are present here. For a standalone deployment, replace those adapter boundaries with equivalents from your hosting/authentication providers, configure the environment values in `.env`, provision MySQL, and deploy the Node server.

GitHub Pages cannot run this server, database, SMTP service, or protected integrations. It hosts only the public marketing files at the repository root.
