# Environment Configuration

SignalForge requires server-side configuration. Create your local environment file through your deployment platform or secret manager and provide the following keys. **Do not commit real values to Git.**

| Variable | Required | Purpose |
| --- | --- | --- |
| `DATABASE_URL` | Yes | MySQL-compatible database connection string. |
| `JWT_SECRET` | Yes | Long random value used to sign sessions. |
| `OAUTH_SERVER_URL` | Yes | Authentication provider/server URL. |
| `VITE_APP_ID` | Yes | Client application identifier for authentication. |
| `VITE_OAUTH_PORTAL_URL` | Yes | Client authentication portal URL. |
| `OWNER_OPEN_ID` | Yes | Owner identifier used by app-level access controls. |
| `OWNER_NAME` | Yes | Owner display name. |
| `BUILT_IN_FORGE_API_URL` | Provider-dependent | Server-side platform-service endpoint. |
| `BUILT_IN_FORGE_API_KEY` | Provider-dependent | Server-side platform-service key. |
| `VITE_FRONTEND_FORGE_API_URL` | Provider-dependent | Publicly scoped frontend service endpoint. |
| `VITE_FRONTEND_FORGE_API_KEY` | Provider-dependent | Publicly scoped frontend service key. |
| `VITE_ANALYTICS_ENDPOINT` | Optional | Analytics endpoint. |
| `VITE_ANALYTICS_WEBSITE_ID` | Optional | Analytics site identifier. |

Use your hosting platform's encrypted secret manager for production values. For local development, create a private environment file that is excluded by `.gitignore`.
