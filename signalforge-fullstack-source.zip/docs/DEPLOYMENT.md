# Deployment Architecture

SignalForge is a **full-stack application** with a separate static public-facing website. This repository intentionally contains both, but they are deployed differently.

| Component | Repository location | What it does | Where it runs |
| --- | --- | --- | --- |
| Public website | repository root | Product narrative, brand, beta call to action, SEO/social metadata | GitHub Pages |
| Application client | `app/client/` | Authenticated user interface for discovery, lead management, reviews, outreach, compliance, and settings | Vite build served by the application server |
| Application server | `app/server/` | tRPC API, email workflows, encryption, discovery services, policy enforcement | Node.js-compatible service |
| Database | `app/drizzle/` | Schema and migrations for MySQL-compatible storage | Managed MySQL / TiDB-compatible database |

## Why GitHub Pages is not the full application

GitHub Pages serves static files. It does not provide a Node.js process, a protected environment-variable store, a database connection, or a long-lived encrypted SMTP service. For that reason, publishing the complete source code does not make the secure product server run on GitHub Pages. The Pages site is the product's public front door; the application requires a server-side deployment.

## Deploying the application elsewhere

Provision a MySQL-compatible database, configure the environment variables listed in `app/.env.example`, run the Drizzle migrations, and deploy the Node build from `app/`. The platform-specific adapter files in `app/server/_core/` must be connected to the selected authentication, storage, mapping, LLM, and notification services. Keep all production secrets in the deployment platform's secret manager.

## GitHub Pages configuration

The marketing website publishes from the `main` branch at repository root. Do not select `app/` as the Pages source; it is application source code, not a static site build.
