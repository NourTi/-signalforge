# SignalForge Product Guide

SignalForge is an approval-first B2B prospecting workspace. It turns public business information into a private, reviewable lead pipeline and never sends outreach automatically.

## A typical workflow

| Step | What the user does | SignalForge does |
| --- | --- | --- |
| 1. Discover | Chooses a keyword, industry, business type, city, country, and mode | Finds relevant public businesses and records source provenance |
| 2. Review | Inspects the company and contact data before saving | Extracts only visible business email addresses from official websites |
| 3. Qualify | Adds notes, status, and research context | Keeps a per-lead activity trail and pipeline record |
| 4. Draft | Requests an outreach draft with a clear commercial purpose | Produces a reviewable draft; it does not send it |
| 5. Approve | Checks the draft, sender identity, suppression state, and deliverability readiness | Blocks unsafe or non-compliant sends |
| 6. Confirm | Performs a final intentional confirmation | Dispatches through the user's encrypted SMTP configuration and records the outcome |

## What the product is designed to prevent

SignalForge is intentionally not a bulk-spam machine. The product includes recipient suppression, signed opt-out links, sender profiles, daily sending limits, DNS-readiness guidance, clear footer controls, and a final confirmation step. Any recipient who opts out is blocked from further drafting and delivery for that sender.

## Who it is for

The product is suited to founder-led B2B teams, boutique agencies, consultants, RevOps operators, and sales teams that want a more deliberate prospecting workflow without surrendering judgment to automation.
